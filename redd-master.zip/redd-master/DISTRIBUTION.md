# Distributing Redd Master 1.0

Four realistic ways to get this onto crew devices, cheapest and fastest first.
**For a field crew, Option 1 is almost certainly what you want** — the others exist for
specific reasons, and I've been honest about what each one costs you.

Redd Master already passes every technical requirement for all four routes: valid manifest,
512px and maskable icons, screenshots, offline service worker, and a unique app id.

---

## Option 1 — Install straight from the web (recommended)

**Cost:** free · **Time:** ~2 minutes · **Accounts needed:** none

This is what the app is built for. Publish once, and every crew member installs it from a
link. It lands on the home screen with its own icon, opens without browser chrome, and works
with no signal.

See `INSTALL.md` for the click-by-click. Short version: drag the folder onto
<https://app.netlify.com/drop>, open the URL on the phone, then
**iPhone: Safari → Share → Add to Home Screen**, **Android: Chrome → ⋮ → Install app**.

**What you give up:** it isn't in the App Store or Play Store, and iPhone users must use
Safari to install it. That's it. It is a real installed app in every way that matters in the
field.

---

## Option 2 — A real Android `.apk` file you can hand out

**Cost:** free · **Time:** ~15 minutes · **Accounts needed:** none for sideloading

If you specifically want a **downloadable file** — to email to crew, put on a shared drive, or
install without a URL — this produces a genuine Android app package.

1. Complete Option 1 first. You need the app live at a URL.
2. Go to **<https://www.pwabuilder.com>**
3. Paste your URL and press **Start**. It will score the app; Redd Master should pass cleanly.
4. Choose **Android → Generate Package**.
5. In the options, set:
   - **Package ID:** something like `org.lummi.reddmaster` (this is permanent — pick carefully)
   - **App name:** Redd Master
   - **Signing key:** choose **Create new** and **download the `.keystore` file it gives you**
6. You get a zip containing:
   - `app-release-signed.apk` — the file you hand out and install
   - `app-release-bundle.aab` — only needed if you later publish to Play Store
   - your signing key — **back this up; without it you can never update the app**

**To install the APK:** email or AirDrop it to the Android phone, tap it, and allow
"Install unknown apps" when prompted.

**Important:** this technique (a Trusted Web Activity) shows a browser address bar unless you
verify ownership of the domain. To remove it, edit `.well-known/assetlinks.json` in this
folder — replace the package name and the SHA-256 fingerprint that PWABuilder gives you — and
re-upload so it is reachable at `https://yoursite/.well-known/assetlinks.json`.

**This does not work for iPhone.** Apple does not permit sideloading. iOS is Option 1 or
Option 3, no exceptions.

---

## Option 3 — Google Play and the Apple App Store

**Cost:** Google $25 once · Apple $99/year · **Time:** days to weeks · **Accounts:** developer
accounts, and for a tribal program likely an organisational one

Worth it only if you need the app discoverable by the public, or your IT policy requires
store-managed installs.

- **Google Play:** upload the `.aab` from Option 2. Straightforward.
- **Apple App Store:** requires a Mac with Xcode, an Apple Developer account, and wrapping the
  app (PWABuilder can generate the iOS project). Be aware Apple rejects apps that are thin
  wrappers around a website — Redd Master's offline forms, Excel export and reference section
  are substantial enough to argue, but budget for a review round or two.

You will also need: privacy policy URL, store listing text, and screenshots
(`screenshot-survey.png` and `screenshot-tally.png` are included; store icons are
`store-icon-512.png` and `store-icon-1024.png`).

---

## Option 4 — Managed deployment through LNR IT

**Cost:** depends on existing infrastructure · **Time:** an IT conversation

If Lummi Natural Resources already manages work phones (Intune, Jamf, Google Workspace, or
similar), the cleanest path is to hand IT this folder and ask them to:

- host it on an internal HTTPS address, and
- push the install to managed devices, or distribute the APK from Option 2 internally

This keeps everything on tribal infrastructure and nothing on a third-party host. If the data
is at all sensitive politically or legally, **this is the option to ask about first.**

---

## Which should you pick?

| Your situation | Route |
|---|---|
| Crew of any size, mixed iPhone and Android | **Option 1** |
| You want a file to hand out, Android only | **Option 2** |
| IT manages the phones | **Option 4** |
| It must be publicly downloadable by name | **Option 3** |
| iPhones involved and you can't use a URL | Only Option 3 — Apple allows nothing else |

---

## Whichever you choose

- **Survey data never leaves the device** in any of these routes. There is no server, no
  account and no telemetry. Exporting is manual and deliberate.
- **Back up the signing key** if you go the APK route. Losing it means you cannot ever ship an
  update to installed devices, only a separate app.
- **Updates:** for Options 1 and 2 you replace the files and bump `CACHE` in `sw.js`; phones
  pick it up on the next launch with signal. For Option 3 you submit a new build.
- **Test airplane mode on a real phone before the season starts**, whichever route you take.

---

## Files in this folder for packaging

| File | Used for |
|---|---|
| `manifest.webmanifest` | Install metadata — already store-ready |
| `screenshot-*.png` | Android install prompt and store listings |
| `store-icon-512.png` | Play Store listing icon |
| `store-icon-1024.png` | Apple App Store listing icon |
| `.well-known/assetlinks.json` | Template — removes the address bar from an Android package |
